import * as React from "react";
export default ({ var1, var2 }) => <button disabled={var1}>{var2}</button>;